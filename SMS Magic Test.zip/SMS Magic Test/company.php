<?php
class Company {
    public $name;
    public $users; // Inverse side relationship named users
}
?>
