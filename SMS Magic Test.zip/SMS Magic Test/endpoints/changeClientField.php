<?php
// api/endpoints/changeClientField.php

require_once '../entities/Client.php';

// Assuming you have a database connection, implement the logic to change client fields
if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $clientId = $_GET['clientId'] ?? '';
    $updatedData = json_decode(file_get_contents('php://input'), true);

    // Use $clientId and $updatedData to update client fields in the database
    // Return the updated client details in JSON format
    echo json_encode(["result" => "Client fields changed successfully"]);
}
?>
