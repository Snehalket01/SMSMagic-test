<?php
class ClientUser {
    public $client;
    public $users;
    public $createdAt;
    public $updatedAt;
    public $deletedAt;
    public $active;
}
?>
