<?php
class Client {
    public $name;
    public $user; // Relational User field
    public $company; // Relational Company field
    public $email; // Only valid emails accepted
    public $phone; // Only numbers accepted

    public function __construct($name, $user, $company, $email, $phone) {
        $this->name = $name;
        $this->user = $user;
        $this->company = $company;
        $this->email = $email;
        $this->phone = $phone;
    }
}
?>
