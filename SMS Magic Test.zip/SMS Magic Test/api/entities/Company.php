<?php
class Company {
    public $name;
    public $users; // Inverse side relationship named users

    public function __construct($name, $users) {
        $this->name = $name;
        $this->users = $users;
    }
}
?>
