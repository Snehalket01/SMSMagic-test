<?php
class User {
    public $user_id;
    public $username;
    public $email;
    public $password;
}
?>
