<?php
class ClientUser {
    public $client;
    public $users;
    public $createdAt;
    public $updatedAt;
    public $deletedAt;
    public $active;

    public function __construct($client, $users, $createdAt, $updatedAt, $deletedAt, $active) {
        $this->client = $client;
        $this->users = $users;
        $this->createdAt = $createdAt;
        $this->updatedAt = $updatedAt;
        $this->deletedAt = $deletedAt;
        $this->active = $active;
    }
}
?>
