<?php
class Client {
    public $name;
    public $user; // Relational User field
    public $company; // Relational Company field
    public $email; // Only valid emails accepted
    public $phone; // Only numbers accepted
}
?>
