<?php
// api/index.php

// Autoload classes
spl_autoload_register(function ($class_name) {
    require_once "entities/$class_name.php";
});

// Include endpoint files
require_once 'endpoints/listUsers.php';
require_once 'endpoints/replaceUserFields.php';
require_once 'endpoints/createClient.php';
require_once 'endpoints/changeClientField.php';
?>
